module.exports = {
    url: 'mongodb://rit-demo:r1td3m0@ds219459.mlab.com:19459/rit-demo'
}
